create view mobileproductview as
SELECT p.id_product,
       p.product_name,
       d.brand,
       d.model,
       d.screen_size,
       d.cpu_core,
       d.cpu_speed,
       d.camera_front,
       d.camera_back,
       d.memory_internal,
       d.memory_external,
       d.fingerprint_reader,
       r.width,
       r.height,
       p.price
FROM ((description_mobile d
  JOIN resolution r ON ((d.id_resolution = r.id_resolution)))
       JOIN product p ON ((p.id_product = d.id_product)));

alter table mobileproductview
  owner to u5wardega;

