create view loginview as
SELECT cl.id_client,
       c.email,
       cl.password
FROM (client cl
       JOIN contact c ON ((cl.id_contact = c.id_contact)));

alter table loginview
  owner to u5wardega;

