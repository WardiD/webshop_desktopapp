create function ocenazegzaminu() returns trigger
  language plpgsql
as
$$
BEGIN
 IF (SELECT COUNT(przedmiot_id) FROM ocena o WHERE o.student_id=new.student_id AND o.przedmiot_id=new.przedmiot_id) < 3 THEN
  RAISE NOTICE 'Dodaje ocene, gdyz student nie wykorzystal do tej pory wszystkic hterminow';
  RETURN NEW;
 ELSE
  RAISE NOTICE 'Nie moge dodac kolejnej oceny gdyz student ma juz oceny z 3 terminow';
  RETURN NULL;
 END IF;
END;
$$;

alter function ocenazegzaminu() owner to u5wardega;

