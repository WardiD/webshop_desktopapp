create function sum_n_product(x integer, y integer, OUT sum integer, OUT product integer) returns record
  language sql
as
$$
SELECT $1+$2, $1*$2
$$;

alter function sum_n_product(integer, integer, out integer, out integer) owner to u5wardega;

