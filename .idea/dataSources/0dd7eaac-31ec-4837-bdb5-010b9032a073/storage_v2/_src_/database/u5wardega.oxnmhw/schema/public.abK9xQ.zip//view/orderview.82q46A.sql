create view orderview as
SELECT t.id_transaction,
       concat(w.first_name, ' ', w.last_name) AS worker_name,
       s.status_name,
       t.creation_date,
       t.realization_date,
       c.cart_price,
       c.id_cart,
       c.id_client
FROM (((transactions t
  LEFT JOIN cart c ON ((t.id_cart = c.id_cart)))
  LEFT JOIN worker w ON ((t.id_worker = w.id_worker)))
       LEFT JOIN status s ON ((t.id_status = s.id_status)))
WHERE (c.ordered = true);

alter table orderview
  owner to u5wardega;

