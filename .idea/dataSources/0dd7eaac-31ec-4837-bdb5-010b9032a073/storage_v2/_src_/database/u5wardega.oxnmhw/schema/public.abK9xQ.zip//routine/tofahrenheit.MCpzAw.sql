create function tofahrenheit() returns void
  language plpgsql
as
$$
DECLARE
 i real := 1.0;
 BEGIN
  WHILE i <=100.0
  LOOP
   INSERT INTO temp_tab VALUES(i,i*1.8+32.00);
   i := i+0.1;
  END LOOP;
  RETURN;
 END;
$$;

alter function tofahrenheit() owner to u5wardega;

