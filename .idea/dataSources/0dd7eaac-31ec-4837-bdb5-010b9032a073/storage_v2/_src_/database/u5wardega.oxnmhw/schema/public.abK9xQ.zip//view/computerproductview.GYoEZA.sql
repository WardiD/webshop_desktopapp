create view computerproductview as
SELECT p.id_product,
       p.product_name,
       d.brand,
       d.model,
       d.processor,
       d.cpu_core,
       d.cpu_speed,
       d.graphic_card,
       d.graphic_memory,
       d.ram,
       d.hdd,
       d.ssd,
       d.dvd,
       d.screen_size,
       r.width,
       r.height,
       p.price
FROM ((description_computer d
  JOIN resolution r ON ((d.id_resolution = r.id_resolution)))
       JOIN product p ON ((p.id_product = d.id_product)));

alter table computerproductview
  owner to u5wardega;

