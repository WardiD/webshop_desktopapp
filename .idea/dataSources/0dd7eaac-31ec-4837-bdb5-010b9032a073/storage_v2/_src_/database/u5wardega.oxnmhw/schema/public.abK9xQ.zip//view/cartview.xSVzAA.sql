create view cartview as
SELECT p.id_product,
       p.product_name,
       pl.quantity,
       p.price,
       c.id_cart,
       c.id_client
FROM ((product_list pl
  JOIN cart c ON ((pl.id_cart = c.id_cart)))
       JOIN product p ON ((pl.id_product = p.id_product)))
WHERE (c.ordered = false);

alter table cartview
  owner to u5wardega;

