create function ileuczniow() returns integer
  language plpgsql
as
$$
DECLARE
 c integer;
 BEGIN
  SELECT COUNT(*) INTO c FROM Student;
  RETURN c;
 END;
$$;

alter function ileuczniow() owner to u5wardega;

