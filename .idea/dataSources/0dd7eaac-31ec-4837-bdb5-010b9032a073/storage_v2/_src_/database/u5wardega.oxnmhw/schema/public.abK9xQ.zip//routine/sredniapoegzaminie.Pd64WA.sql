create function sredniapoegzaminie() returns trigger
  language plpgsql
as
$$
DECLARE
 avg real;
 licznik integer;
 mianownik integer;

BEGIN
 licznik := (SELECT SUM(przedmiot_id) FROM ocena o WHERE o.student_id=new.student_id AND o.przedmiot_id=new.przedmiot_id);
 mianownik := (SELECT COUNT(przedmiot_id) FROM ocena o WHERE o.student_id=new.student_id AND o.przedmiot_id=new.przedmiot_id);
 avg := (licznik/mianownik);
 IF mianownik = 1 THEN
  INSERT INTO srednia(student_id,przedmiot_id,liczbaprob,srednia) VALUES (new.student_id,new.przedmiot_id,mianownik,avg);
 ELSE
  UPDATE srednia s SET srednia=avg WHERE s.student_id=new.student_id AND s.przedmiot_id=new.przedmiot_id;
 END IF;
 RETURN NULL;
END;
$$;

alter function sredniapoegzaminie() owner to u5wardega;

