create view generalproductview as
SELECT p.product_name,
       p.id_product,
       t.type_name,
       p.price,
       p.quantity_store
FROM (product p
       JOIN product_type t ON ((p.id_type = t.id_type)));

alter table generalproductview
  owner to u5wardega;

