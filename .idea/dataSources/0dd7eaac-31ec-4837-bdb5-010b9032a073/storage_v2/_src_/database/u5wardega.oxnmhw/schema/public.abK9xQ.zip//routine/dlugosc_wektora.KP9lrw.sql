create function dlugosc_wektora(real, real, real, real) returns real
  language plpgsql
as
$$
DECLARE
 x1 ALIAS FOR $1;
 y1 ALIAS FOR $2;
 x2 ALIAS FOR $3;
 y2 ALIAS FOR $4;
 BEGIN
  RETURN SQRT((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
 END;
$$;

alter function dlugosc_wektora(real, real, real, real) owner to u5wardega;

