create function wielomian(integer, integer, integer) returns void
  language plpgsql
as
$$
DECLARE
 A ALIAS FOR $1;
 B ALIAS FOR $2;
 C ALIAS FOR $3;
 BEGIN
  FOR i IN 1..100
  LOOP
   INSERT INTO war_wielomianu VALUES(i,A*i^2+B*i+C);
  END LOOP;
  RETURN;
 END;
$$;

alter function wielomian(integer, integer, integer) owner to u5wardega;

